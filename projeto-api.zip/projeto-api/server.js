const express = require("express")
const cors = require("cors")
require("dotenv").config()

const alunoRoutes = require("./src/routes/alunoRoutes")
const planoRoutes = require("./src/routes/planoRoutes")

const app = express()

app.use(cors())
app.use(express.json())

app.use("/api/alunos", alunoRoutes)
app.use("/api/planos", planoRoutes)

app.listen(process.env.PORT, () => {
    console.log("Servidor rodando em http://localhost:3000")
})