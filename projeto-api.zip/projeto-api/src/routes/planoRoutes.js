const express = require("express")
const router = express.Router()
const controller = require("../controllers/planoController")

router.get("/", controller.listarPlanos)
router.post("/", controller.cadastrarPlano)
router.delete("/:id", controller.removerPlano)

module.exports = router