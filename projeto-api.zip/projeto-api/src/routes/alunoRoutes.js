const express = require("express")
const router = express.Router()
const controller = require("../controllers/alunoController")

router.get("/", controller.listarAlunos)
router.get("/:id", controller.buscarAluno)
router.post("/", controller.cadastrarAluno)
router.put("/:id", controller.atualizarAluno)
router.delete("/:id", controller.removerAluno)

module.exports = router