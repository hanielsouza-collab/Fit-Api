const db = require("../database/db")

const listarAlunos = (req, res) => {
    db.query("SELECT * FROM alunos", (erro, resultado) => {
        if (erro) return res.status(500).json(erro)
        res.json(resultado)
    })
}

const buscarAluno = (req, res) => {
    const { id } = req.params

    db.query("SELECT * FROM alunos WHERE id = ?", [id], (erro, resultado) => {
        if (erro) return res.status(500).json(erro)
        res.json(resultado)
    })
}

const cadastrarAluno = (req, res) => {
    const { nome, idade, peso, altura, plano_id } = req.body

    db.query(
        "INSERT INTO alunos(nome, idade, peso, altura, plano_id) VALUES (?, ?, ?, ?, ?)",
        [nome, idade, peso, altura, plano_id],
        (erro) => {
            if (erro) return res.status(500).json(erro)
            res.json({ mensagem: "Aluno cadastrado" })
        }
    )
}

const atualizarAluno = (req, res) => {
    const { id } = req.params
    const { nome, idade, peso, altura, plano_id } = req.body

    db.query(
        "UPDATE alunos SET nome=?, idade=?, peso=?, altura=?, plano_id=? WHERE id=?",
        [nome, idade, peso, altura, plano_id, id],
        (erro) => {
            if (erro) return res.status(500).json(erro)
            res.json({ mensagem: "Aluno atualizado" })
        }
    )
}

const removerAluno = (req, res) => {
    const { id } = req.params

    db.query("DELETE FROM alunos WHERE id = ?", [id], (erro) => {
        if (erro) return res.status(500).json(erro)
        res.json({ mensagem: "Aluno removido" })
    })
}

module.exports = {
    listarAlunos,
    buscarAluno,
    cadastrarAluno,
    atualizarAluno,
    removerAluno
}