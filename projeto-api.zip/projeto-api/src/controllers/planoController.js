const db = require("../database/db")

const listarPlanos = (req, res) => {
    db.query("SELECT * FROM planos", (erro, resultado) => {
        if (erro) return res.status(500).json(erro)
        res.json(resultado)
    })
}

const cadastrarPlano = (req, res) => {
    const { nome_plano, duracao, preco, beneficios, status } = req.body

    db.query(
        "INSERT INTO planos(nome_plano, duracao, preco, beneficios, status) VALUES (?, ?, ?, ?, ?)",
        [nome_plano, duracao, preco, beneficios, status],
        (erro) => {
            if (erro) return res.status(500).json(erro)
            res.json({ mensagem: "Plano cadastrado" })
        }
    )
}

const removerPlano = (req, res) => {
    const { id } = req.params

    db.query("DELETE FROM planos WHERE id = ?", [id], (erro) => {
        if (erro) return res.status(500).json(erro)
        res.json({ mensagem: "Plano removido" })
    })
}

module.exports = {
    listarPlanos,
    cadastrarPlano,
    removerPlano
}