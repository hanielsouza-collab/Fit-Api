const api = "http://localhost:3000/api/alunos"

async function carregarAlunos() {
    const resposta = await fetch(api)
    const dados = await resposta.json()

    const lista = document.getElementById("listaAlunos")
    lista.innerHTML = ""

    dados.forEach(aluno => {
        lista.innerHTML += `
            <div class="card">
                <h3>${aluno.nome}</h3>
                <p>Idade: ${aluno.idade}</p>
                <p>Peso: ${aluno.peso}</p>
                <p>Altura: ${aluno.altura}</p>
                <p>Plano ID: ${aluno.plano_id}</p>
            </div>
        `
    })
}

document.getElementById("formAluno").addEventListener("submit", async (e) => {
    e.preventDefault()

    const novoAluno = {
        nome: document.getElementById("nome").value,
        idade: document.getElementById("idade").value,
        peso: document.getElementById("peso").value,
        altura: document.getElementById("altura").value,
        plano_id: document.getElementById("plano_id").value
    }

    await fetch(api, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(novoAluno)
    })

    document.getElementById("formAluno").reset()
    carregarAlunos()
})

carregarAlunos()