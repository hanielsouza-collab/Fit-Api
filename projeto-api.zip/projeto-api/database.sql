CREATE DATABASE IF NOT EXISTS fitmanager;

USE fitmanager;

CREATE TABLE IF NOT EXISTS planos (
 id INT PRIMARY KEY AUTO_INCREMENT,
 nome_plano VARCHAR(50),
 duracao VARCHAR(30),
 preco DECIMAL(10,2),
 beneficios TEXT,
 status VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS alunos (
 id INT PRIMARY KEY AUTO_INCREMENT,
 nome VARCHAR(100),
 idade INT,
 peso DECIMAL(5,2),
 altura DECIMAL(4,2),
 plano_id INT
);

INSERT INTO planos (nome_plano, duracao, preco, beneficios, status)
VALUES
('Básico', '1 mês', 79.90, 'Musculação', 'Ativo'),
('Premium', '3 meses', 199.90, 'Musculação + Cardio', 'Ativo');

INSERT INTO alunos (nome, idade, peso, altura, plano_id)
VALUES
('Carlos Silva', 22, 75.5, 1.78, 1),
('Ana Souza', 20, 58.2, 1.65, 2);